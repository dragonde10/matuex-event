export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  location: string;
  description: string;
  image: string;
}

export interface Ticket {
  id: string;
  eventId: string;
  type: string;
  price: number;
  hasDiscount: boolean;
  discountPercentage?: number;
  discountedPrice?: number;
}

export interface CartItem {
  ticket: Ticket;
  quantity: number;
}

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  featured?: boolean;
}