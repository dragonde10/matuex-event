import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const { getTotalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navigateTo = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-black bg-opacity-90 shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div 
          className="text-2xl font-bold cursor-pointer" 
          onClick={() => navigateTo('/')}
        >
          M<span className="text-red-600">.</span>
        </div>

        <nav className="hidden md:flex items-center space-x-8">
          <a href="#eventos" className="text-white hover:text-red-500 transition-colors">Eventos</a>
          <a href="#galeria" className="text-white hover:text-red-500 transition-colors">Galeria</a>
          <a href="#ingressos" className="text-white hover:text-red-500 transition-colors">Ingressos</a>
          <button 
            onClick={() => navigateTo('/cart')}
            className="flex items-center text-white hover:text-red-500 transition-colors"
          >
            <ShoppingCart size={20} className="mr-1" />
            <span className="bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {getTotalItems()}
            </span>
          </button>
        </nav>

        <div className="md:hidden flex items-center">
          <button 
            onClick={() => navigateTo('/cart')}
            className="mr-4 relative"
          >
            <ShoppingCart size={24} className="text-white" />
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {getTotalItems()}
              </span>
            )}
          </button>
          <button
            onClick={toggleMenu}
            className="text-white focus:outline-none"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-black bg-opacity-95 absolute w-full py-4 animate-fade-in-down">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <a 
              href="#eventos" 
              className="text-white hover:text-red-500 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Eventos
            </a>
            <a 
              href="#galeria" 
              className="text-white hover:text-red-500 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Galeria
            </a>
            <a 
              href="#ingressos" 
              className="text-white hover:text-red-500 transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Ingressos
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;