import React, { useState } from 'react';
import { GalleryImage } from '../types/types';
import { X } from 'lucide-react';

interface GalleryProps {
  images: GalleryImage[];
}

const Gallery: React.FC<GalleryProps> = ({ images }) => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const openLightbox = (image: GalleryImage) => {
    setSelectedImage(image);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  // Find the featured image and regular images
  const featuredImage = images.find(img => img.featured);
  const regularImages = images.filter(img => !img.featured);

  return (
    <section id="galeria" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          Galeria de <span className="text-red-600">Fotos</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {featuredImage && (
            <div 
              className="md:col-span-2 md:row-span-2 relative cursor-pointer overflow-hidden rounded-xl"
              onClick={() => openLightbox(featuredImage)}
            >
              <img 
                src={featuredImage.src} 
                alt={featuredImage.alt}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 hover:bg-opacity-40 transition-opacity flex items-center justify-center opacity-0 hover:opacity-100">
                <span className="text-white text-lg font-semibold">Ver Ampliado</span>
              </div>
            </div>
          )}
          
          {regularImages.map((image) => (
            <div 
              key={image.id}
              className="relative cursor-pointer overflow-hidden rounded-xl h-48 md:h-auto"
              onClick={() => openLightbox(image)}
            >
              <img 
                src={image.src} 
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 hover:bg-opacity-40 transition-opacity flex items-center justify-center opacity-0 hover:opacity-100">
                <span className="text-white text-sm font-semibold">Ver Ampliado</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Lightbox */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center p-4">
          <button 
            className="absolute top-4 right-4 text-white hover:text-red-500 transition-colors"
            onClick={closeLightbox}
          >
            <X size={32} />
          </button>
          
          <div className="max-w-4xl max-h-[90vh] overflow-hidden">
            <img 
              src={selectedImage.src}
              alt={selectedImage.alt}
              className="max-w-full max-h-[90vh] object-contain"
            />
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;