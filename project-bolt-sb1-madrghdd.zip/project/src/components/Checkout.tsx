import React, { useState } from 'react';
import { Copy, Check, AlertCircle } from 'lucide-react';
import QRCode from 'react-qr-code';
import { useCart } from '../context/CartContext';

const Checkout: React.FC = () => {
  const { cartItems, getTotalPrice, clearCart } = useCart();
  const [copied, setCopied] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  // Mock PIX data
  const pixCode = "00020126580014br.gov.bcb.pix0136payment@example.com5204000053039865802BR5913Matue Eventos6008Sao Paulo62070503***6304D2CE";
  
  const handleCopyCode = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const handleCompleteCheckout = () => {
    setShowConfirmation(true);
    clearCart();
  };

  if (showConfirmation) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 text-center">
        <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check size={32} className="text-white" />
        </div>
        <h2 className="text-2xl font-bold mb-4">Pagamento Concluído!</h2>
        <p className="text-gray-300 mb-6">
          Seu ingresso foi confirmado e foi enviado para seu e-mail.
          Você também pode acessá-lo em "Meus Ingressos" na sua conta.
        </p>
        <button
          onClick={() => window.location.href = '/'}
          className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
        >
          Voltar para a página inicial
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl overflow-hidden">
      <div className="p-8">
        <h2 className="text-2xl font-bold mb-6">Finalizar Compra</h2>
        
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Seus Ingressos</h3>
          
          {cartItems.map((item, index) => (
            <div 
              key={`${item.ticket.id}-${index}`}
              className="flex justify-between items-center py-3 border-b border-gray-800"
            >
              <div>
                <p className="font-medium">{item.ticket.type}</p>
                <p className="text-sm text-gray-400">Quantidade: {item.quantity}</p>
              </div>
              <div className="text-right">
                <p className="font-medium">
                  R$ {((item.ticket.hasDiscount && item.ticket.discountedPrice ? 
                        item.ticket.discountedPrice : 
                        item.ticket.price) * item.quantity).toFixed(2)}
                </p>
                {item.ticket.hasDiscount && (
                  <p className="text-sm text-green-500">
                    {item.ticket.discountPercentage}% desconto aplicado
                  </p>
                )}
              </div>
            </div>
          ))}
          
          <div className="flex justify-between items-center py-4 font-bold text-lg">
            <span>Total:</span>
            <span>R$ {getTotalPrice().toFixed(2)}</span>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Pagar com PIX</h3>
            <div className="bg-green-600 text-white text-xs font-medium px-3 py-1 rounded-full">
              Único método disponível
            </div>
          </div>
          
          <div className="flex flex-col items-center mb-6">
            <div className="bg-white p-4 rounded-lg mb-4">
              <QRCode value={pixCode} size={180} />
            </div>
            <p className="text-sm text-gray-400 text-center mb-4">
              Escaneie o código QR com o app do seu banco ou copie o código PIX abaixo
            </p>
            
            <div className="w-full relative">
              <input
                type="text"
                value={pixCode}
                readOnly
                className="w-full bg-gray-700 border border-gray-600 rounded-lg py-3 px-4 pr-12 text-sm"
              />
              <button
                onClick={handleCopyCode}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
              >
                {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
              </button>
            </div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-4 flex items-start">
            <AlertCircle size={20} className="text-yellow-500 mr-3 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-gray-300">
              Após realizar o pagamento via PIX, o processamento pode levar até 1 minuto. 
              Não feche esta página até a confirmação aparecer.
            </p>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button
            onClick={() => window.history.back()}
            className="bg-transparent border border-gray-600 hover:border-gray-500 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
          >
            Voltar
          </button>
          
          <button
            onClick={handleCompleteCheckout}
            className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
          >
            Confirmar Pagamento
          </button>
        </div>
      </div>
    </div>
  );
};

export default Checkout;