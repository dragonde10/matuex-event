import React from 'react';
import { Event } from '../types/types';
import { Calendar, Clock, MapPin, Music, Info } from 'lucide-react';

interface EventDetailsProps {
  events: Event[];
}

const EventDetails: React.FC<EventDetailsProps> = ({ events }) => {
  return (
    <section id="eventos" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          Próximos <span className="text-red-600">Eventos</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {events.map((event) => (
            <div 
              key={event.id}
              className="bg-gray-800 rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-[0_0_15px_rgba(220,38,38,0.3)] hover:-translate-y-1"
            >
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={event.image} 
                  alt={event.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-4">{event.title}</h3>
                
                <div className="space-y-3 mb-4">
                  <div className="flex items-center">
                    <Calendar size={18} className="mr-2 text-red-500" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock size={18} className="mr-2 text-red-500" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin size={18} className="mr-2 text-red-500" />
                    <span>{event.venue} - {event.location}</span>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 line-clamp-3">
                  {event.description}
                </p>
                
                <div className="flex justify-between items-center">
                  <a 
                    href="#ingressos" 
                    className="bg-red-600 hover:bg-red-700 text-white font-semibold px-5 py-2 rounded-lg transition-colors"
                  >
                    Comprar Ingressos
                  </a>
                  
                  <button 
                    className="text-white hover:text-red-500 transition-colors"
                    aria-label="Mais informações"
                  >
                    <Info size={20} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EventDetails;