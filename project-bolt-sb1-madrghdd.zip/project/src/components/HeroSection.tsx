import React, { useState, useEffect } from 'react';
import { Event } from '../types/types';
import { Calendar, MapPin, Clock } from 'lucide-react';

interface HeroSectionProps {
  event: Event;
}

const HeroSection: React.FC<HeroSectionProps> = ({ event }) => {
  const [countdown, setCountdown] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateCountdown = () => {
      // Parse the event date (assuming format: "28 de Junho de 2025")
      const monthMap: { [key: string]: number } = {
        'janeiro': 0, 'fevereiro': 1, 'março': 2, 'abril': 3,
        'maio': 4, 'junho': 5, 'julho': 6, 'agosto': 7,
        'setembro': 8, 'outubro': 9, 'novembro': 10, 'dezembro': 11
      };
      
      const [day, _, month, year] = event.date.split(' ');
      const [hour, minute] = event.time.split(':');
      
      const eventDate = new Date(
        parseInt(year),
        monthMap[month.toLowerCase()],
        parseInt(day),
        parseInt(hour),
        parseInt(minute)
      );
      
      const now = new Date();
      const diff = eventDate.getTime() - now.getTime();
      
      if (diff <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      
      return { days, hours, minutes, seconds };
    };
    
    const intervalId = setInterval(() => {
      setCountdown(calculateCountdown());
    }, 1000);
    
    // Initial calculation
    setCountdown(calculateCountdown());
    
    return () => clearInterval(intervalId);
  }, [event]);

  return (
    <div className="relative w-full h-screen min-h-[600px] overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${event.image})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/50 to-black"></div>
      </div>
      
      {/* Content */}
      <div className="relative h-full container mx-auto px-4 pt-32 flex flex-col justify-center">
        <div className="max-w-2xl animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
            {event.title}
          </h1>
          
          <div className="space-y-3 mb-8">
            <div className="flex items-center text-lg">
              <Calendar size={20} className="mr-2 text-red-500" />
              <span>{event.date}</span>
            </div>
            <div className="flex items-center text-lg">
              <Clock size={20} className="mr-2 text-red-500" />
              <span>{event.time}</span>
            </div>
            <div className="flex items-center text-lg">
              <MapPin size={20} className="mr-2 text-red-500" />
              <span>{event.venue} - {event.location}</span>
            </div>
          </div>
          
          <p className="text-lg mb-8 text-gray-300">
            {event.description}
          </p>
          
          <a 
            href="#ingressos"
            className="inline-block bg-red-600 hover:bg-red-700 text-white font-semibold px-8 py-3 rounded-lg transition-colors duration-300 transform hover:scale-105"
          >
            Comprar Ingressos
          </a>
        </div>
        
        {/* Countdown */}
        <div className="absolute bottom-8 left-0 w-full px-4">
          <div className="container mx-auto">
            <div className="bg-black/80 backdrop-blur-sm rounded-xl p-4 max-w-md">
              <h3 className="text-lg font-semibold mb-2">Contagem Regressiva</h3>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-gray-900 rounded-lg p-2">
                  <div className="text-2xl font-bold text-red-500">{countdown.days}</div>
                  <div className="text-xs text-gray-400">Dias</div>
                </div>
                <div className="bg-gray-900 rounded-lg p-2">
                  <div className="text-2xl font-bold text-red-500">{countdown.hours}</div>
                  <div className="text-xs text-gray-400">Horas</div>
                </div>
                <div className="bg-gray-900 rounded-lg p-2">
                  <div className="text-2xl font-bold text-red-500">{countdown.minutes}</div>
                  <div className="text-xs text-gray-400">Min</div>
                </div>
                <div className="bg-gray-900 rounded-lg p-2">
                  <div className="text-2xl font-bold text-red-500">{countdown.seconds}</div>
                  <div className="text-xs text-gray-400">Seg</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;