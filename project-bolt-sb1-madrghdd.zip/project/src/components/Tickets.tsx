import React from 'react';
import { Event, Ticket } from '../types/types';
import { Ticket as TicketIcon, Tag, Percent } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface TicketsProps {
  events: Event[];
  tickets: Ticket[];
}

const Tickets: React.FC<TicketsProps> = ({ events, tickets }) => {
  const { addToCart } = useCart();
  
  // Group tickets by event
  const ticketsByEvent = events.map(event => {
    const eventTickets = tickets.filter(ticket => ticket.eventId === event.id);
    return {
      event,
      tickets: eventTickets
    };
  });

  return (
    <section id="ingressos" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          <span className="text-red-600">Ingressos</span> Disponíveis
        </h2>
        
        {ticketsByEvent.map(({ event, tickets }) => (
          <div key={event.id} className="mb-16">
            <h3 className="text-2xl font-bold mb-6">{event.title}</h3>
            <p className="mb-2 text-gray-300">{event.venue} - {event.location}</p>
            <p className="mb-8 text-gray-300">{event.date} às {event.time}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tickets.map((ticket) => (
                <div 
                  key={ticket.id}
                  className={`
                    rounded-xl overflow-hidden transform transition-all duration-300 hover:-translate-y-1
                    ${ticket.hasDiscount 
                      ? 'bg-gradient-to-br from-gray-800 to-gray-900 border border-green-500/30' 
                      : 'bg-gray-800'}
                  `}
                >
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center">
                        <TicketIcon size={20} className="mr-2 text-red-500" />
                        <h4 className="text-xl font-semibold">{ticket.type}</h4>
                      </div>
                      
                      {ticket.hasDiscount && (
                        <div className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                          <Percent size={12} className="mr-1" />
                          {ticket.discountPercentage}% OFF
                        </div>
                      )}
                    </div>
                    
                    <div className="mb-6">
                      {ticket.hasDiscount && ticket.discountedPrice ? (
                        <div>
                          <div className="flex items-center mb-1">
                            <span className="text-gray-400 text-sm line-through mr-2">
                              R$ {ticket.price.toFixed(2)}
                            </span>
                            <Tag size={14} className="text-green-500" />
                          </div>
                          <div className="text-2xl font-bold text-white">
                            R$ {ticket.discountedPrice.toFixed(2)}
                          </div>
                        </div>
                      ) : (
                        <div className="text-2xl font-bold text-white">
                          R$ {ticket.price.toFixed(2)}
                        </div>
                      )}
                    </div>
                    
                    <button
                      onClick={() => addToCart(ticket)}
                      className={`
                        w-full py-3 rounded-lg font-semibold transition-colors
                        ${ticket.hasDiscount
                          ? 'bg-green-600 hover:bg-green-700 text-white'
                          : 'bg-red-600 hover:bg-red-700 text-white'}
                      `}
                    >
                      Adicionar ao Carrinho
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
        
        <div className="mt-12 bg-gray-800 rounded-xl p-6">
          <h3 className="text-xl font-bold mb-4">Informações Adicionais</h3>
          <ul className="space-y-2 text-gray-300">
            <li className="flex items-start">
              <span className="text-red-500 mr-2">•</span>
              Classificação: 16 anos
            </li>
            <li className="flex items-start">
              <span className="text-red-500 mr-2">•</span>
              Proibida a entrada com bebidas e objetos cortantes
            </li>
            <li className="flex items-start">
              <span className="text-red-500 mr-2">•</span>
              Meia-entrada disponível conforme legislação
            </li>
            <li className="flex items-start">
              <span className="text-red-500 mr-2">•</span>
              Ingressos sujeitos à disponibilidade
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Tickets;