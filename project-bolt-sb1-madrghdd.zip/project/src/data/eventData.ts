import { Event, Ticket, GalleryImage } from '../types/types';

export const events: Event[] = [
  {
    id: 'matue-brandao-rj',
    title: 'Matuê e Brandão',
    date: '28 de Junho de 2025',
    time: '21:00',
    venue: 'Parque de Exposições',
    location: 'São João de Meriti, RJ',
    description: 'Prepare-se para uma noite inesquecível com os astros do trap nacional! Matuê e Brandão se apresentam em São João de Meriti com um show eletrizante que promete muita música, energia e vibração. Garanta já seu ingresso!',
    image: 'https://uhuu.com/media/images/events/matue-brandao.jpg'
  },
  {
    id: 'matue-sp',
    title: 'Matuê - 777 Tour',
    date: '15 de Julho de 2025',
    time: '22:00',
    venue: 'Allianz Parque',
    location: 'São Paulo, SP',
    description: 'Matuê chega a São Paulo com sua 777 Tour, trazendo todos os hits que dominaram as paradas nos últimos anos. Um show imperdível para os fãs do trap brasileiro!',
    image: 'https://pbs.twimg.com/media/F_dYkzDWIAEoD4K?format=jpg&name=large'
  }
];

export const tickets: Ticket[] = [
  {
    id: 'pista-rj',
    eventId: 'matue-brandao-rj',
    type: 'Pista',
    price: 80.00,
    hasDiscount: true,
    discountPercentage: 15,
    discountedPrice: 68.00
  },
  {
    id: 'pista-premium-rj',
    eventId: 'matue-brandao-rj',
    type: 'Pista Premium',
    price: 150.00,
    hasDiscount: true,
    discountPercentage: 15,
    discountedPrice: 127.50
  },
  {
    id: 'camarote-rj',
    eventId: 'matue-brandao-rj',
    type: 'Camarote',
    price: 250.00,
    hasDiscount: true,
    discountPercentage: 15,
    discountedPrice: 212.50
  },
  {
    id: 'pista-sp',
    eventId: 'matue-sp',
    type: 'Pista',
    price: 120.00,
    hasDiscount: false
  },
  {
    id: 'pista-premium-sp',
    eventId: 'matue-sp',
    type: 'Pista Premium',
    price: 220.00,
    hasDiscount: false
  },
  {
    id: 'camarote-sp',
    eventId: 'matue-sp',
    type: 'Camarote',
    price: 380.00,
    hasDiscount: false
  }
];

export const galleryImages: GalleryImage[] = [
  {
    id: 'img-1',
    src: 'https://portalrapmais.com/wp-content/uploads/2023/09/matue-30praum-scaled.webp',
    alt: 'Matuê em show recente',
    featured: true
  },
  {
    id: 'img-2',
    src: 'https://i.ytimg.com/vi/LyFIoyfNsLc/maxresdefault.jpg',
    alt: 'Matuê durante performance'
  },
  {
    id: 'img-3',
    src: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrcIcRfqKYXUYAMWH7Nn6qWlDC7ZJCl6QZ5A&usqp=CAU',
    alt: 'Matuê com óculos escuros'
  },
  {
    id: 'img-4',
    src: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxejcXm_-3x7lXLGvRAJVEbSSa-4uyDnghSA&usqp=CAU',
    alt: 'Matuê no palco'
  },
  {
    id: 'img-5',
    src: 'https://www.tenhomaisdiscosqueamigos.com/wp-content/uploads/2020/09/matue.jpg',
    alt: 'Matuê com fãs'
  },
  {
    id: 'img-6',
    src: 'https://www.cnnbrasil.com.br/wp-content/uploads/sites/12/2022/05/matue.jpg',
    alt: 'Matuê em evento promocional'
  }
];