import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { ShoppingCart, X, ArrowLeft, ShoppingBag } from 'lucide-react';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, getTotalPrice, getTotalItems } = useCart();
  const navigate = useNavigate();

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-white px-4 pt-16">
        <div className="max-w-md w-full text-center py-12">
          <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={32} className="text-gray-500" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Seu carrinho está vazio</h2>
          <p className="text-gray-400 mb-8">
            Você não possui nenhum ingresso no carrinho.
            Explore nossos eventos e adicione ingressos para continuar.
          </p>
          <button
            onClick={() => navigate('/')}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
          >
            Ver Eventos Disponíveis
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white px-4 pt-24 pb-20">
      <div className="container mx-auto max-w-4xl">
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate('/')}
            className="text-gray-400 hover:text-white mr-4 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl md:text-3xl font-bold flex items-center">
            <ShoppingCart size={28} className="mr-3" />
            Seu Carrinho
            <span className="ml-3 bg-red-600 text-white text-sm rounded-full w-6 h-6 flex items-center justify-center">
              {getTotalItems()}
            </span>
          </h1>
        </div>
        
        <div className="bg-gray-900 rounded-xl overflow-hidden mb-6">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-4">Ingressos Selecionados</h2>
            
            <div className="space-y-4">
              {cartItems.map((item, index) => (
                <div 
                  key={`${item.ticket.id}-${index}`}
                  className="flex items-center justify-between py-4 border-b border-gray-800"
                >
                  <div>
                    <h3 className="font-medium">{item.ticket.type}</h3>
                    <p className="text-sm text-gray-400">
                      Quantidade: {item.quantity}
                    </p>
                    {item.ticket.hasDiscount && (
                      <p className="text-sm text-green-500">
                        {item.ticket.discountPercentage}% desconto aplicado
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center">
                    <div className="text-right mr-4">
                      <p className="font-medium">
                        R$ {((item.ticket.hasDiscount && item.ticket.discountedPrice
                              ? item.ticket.discountedPrice 
                              : item.ticket.price) * item.quantity).toFixed(2)}
                      </p>
                    </div>
                    
                    <button
                      onClick={() => removeFromCart(item.ticket.id)}
                      className="text-gray-500 hover:text-red-500 transition-colors"
                      aria-label="Remover"
                    >
                      <X size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex justify-between items-center py-4 mt-2 font-bold text-lg">
              <span>Total:</span>
              <span>R$ {getTotalPrice().toFixed(2)}</span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button
            onClick={() => navigate('/')}
            className="bg-transparent border border-gray-600 hover:border-gray-500 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
          >
            Continuar Comprando
          </button>
          
          <button
            onClick={() => navigate('/checkout')}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
          >
            Finalizar Compra
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartPage;