import React from 'react';
import Checkout from '../components/Checkout';

const CheckoutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white px-4 pt-24 pb-20">
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-2xl md:text-3xl font-bold mb-8">Checkout</h1>
        <Checkout />
      </div>
    </div>
  );
};

export default CheckoutPage;