import React from 'react';
import HeroSection from '../components/HeroSection';
import EventDetails from '../components/EventDetails';
import Gallery from '../components/Gallery';
import Tickets from '../components/Tickets';
import { events, tickets, galleryImages } from '../data/eventData';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white">
      <HeroSection event={events[0]} />
      <EventDetails events={events} />
      <Gallery images={galleryImages} />
      <Tickets events={events} tickets={tickets} />
    </div>
  );
};

export default HomePage;